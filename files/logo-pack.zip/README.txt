Meridian Group logo pack (sample)

meridian-mark.svg  The company mark, for screens and print.

Brand color: #3b4bf5
Use the mark on white or very light backgrounds with clear space around it.
